SBL 1.0 resolved page rendering package
Render target: CH4-P028
Entry file: CH4-P028.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Royal-Assembly-Chamber-production-sheet.png
  Assets/Tomas-character-sheet.png
  Assets/Tomas-expression-sheet.png
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Jeremiel-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zorna-character-sheet.png
  Assets/Huldarah-expression-sheet.png
  Assets/Jeremiel-expression-sheet.png
  Assets/Huldarah-character-sheet.png
  Assets/Zoran_Language_and_script.docx
  Assets/Tomas-canonical-character-specification.txt
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Jeremiel-character-sheet.png
  Assets/Huldarah-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
