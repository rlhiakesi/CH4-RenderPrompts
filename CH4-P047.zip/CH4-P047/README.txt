SBL 1.0 resolved page rendering package
Render target: CH4-P047
Entry file: CH4-P047.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zoran-mana-crystals-production-sheet.png
  Assets/Mount-Elar-expedition-environment.png
  Assets/Royal-Assembly-Chamber-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
