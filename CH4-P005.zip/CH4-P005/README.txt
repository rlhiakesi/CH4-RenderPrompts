SBL 1.0 resolved page rendering package
Render target: CH4-P005
Entry file: CH4-P005.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Royal-Assembly-Chamber-production-sheet.png
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Jeremiel-canonical-character-specification.txt
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Jeremiel-character-sheet.png
  Assets/Jeremiel-expression-sheet.png
  Assets/Six-Schools-symbols-and-diagrams-production-sheet.png
  Assets/Zoran_Language_and_script.docx

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
