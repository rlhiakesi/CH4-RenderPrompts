SBL 1.0 resolved page rendering package
Render target: CH4-P003
Entry file: CH4-P003.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Jeremiel-expression-sheet.png
  Assets/Jeremiel-canonical-character-specification.txt
  Assets/Zoren-canonical-character-specification.txt
  Assets/Jeremiel-character-sheet.png
  Assets/Tomas-character-sheet.png
  Assets/Zoren-expression-sheet.png
  Assets/Zoren-character-sheet.png
  Assets/Royal-Assembly-Chamber-production-sheet.png
  Assets/Tomas-expression-sheet.png
  Assets/Tomas-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
