SBL 1.0 resolved page rendering package
Render target: CH4-P052
Entry file: CH4-P052.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-mana-effects-sheet.png
  Assets/Zoran-research-laboratory-production-sheet.png
  Assets/Tomas-character-sheet.png
  Assets/Zoran-mana-crystals-production-sheet.png
  Assets/Tomas-canonical-character-specification.txt
  Assets/Tomas-expression-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
