SBL 1.0 resolved page rendering package
Render target: CH4-P046
Entry file: CH4-P046.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zoran-mana-crystals-production-sheet.png
  Assets/Josia-character-sheet.png
  Assets/Mount-Elar-expedition-environment.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
